brackets-command-runner
=======================

Bracktes extension that allow develper add dynamically hotkeys for command line tools.
